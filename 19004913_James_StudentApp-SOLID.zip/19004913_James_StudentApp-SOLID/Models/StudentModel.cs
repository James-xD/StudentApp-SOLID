namespace StudentWebAppMVC.Models
{
    public class StudentModel
    {
        public string Name { get; set; }
        public string Course { get; set; }
        public int Age { get; set; }
        public string Timetable { get; set; }

        
    }
}
