# StudentApp_Solid_Principles_PROG7311
LAC 2
Task:
{
  In this LAC, we will explore the SOLID principles of OOP - read more

    Develop an application that allows a the campus admin to manage records of part-time and full-time students. Obviously, the nature of full-time and part-time students differs.
    Ensure that your app aligns with the principles of SOLID.
    In the comments, make sure that you explain, in detail, how your application adhere's to SOLID.
    Add in the functionality to store data persistently (you choose how, I just want to see SOLID being implemented)
    Draw a UML class diagram (using any tool).
    Push your repo to GitHub and drop the link in Teams.
}
